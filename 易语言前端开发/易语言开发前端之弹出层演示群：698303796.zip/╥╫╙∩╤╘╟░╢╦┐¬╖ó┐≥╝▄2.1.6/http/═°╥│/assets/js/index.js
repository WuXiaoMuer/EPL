﻿
main();
function main() {
    var bb = '';
    bb = '网页开发框架v2.1.6.e';
    layer.msg ('感谢使用' + bb);
    
}
$('#tccxs').click(function(){
    弹出层_显示 ('#txx111');
});
