﻿
main();
function main() {
    
}
$('#ann111modelxtb').click(function(){
    layer.alert('您输入了信息：' + $('#modalxx123').val());
});
