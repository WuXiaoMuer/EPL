﻿
imgx_main_stat();
function imgx_main_stat() {
    设置_轮播图 ('#gt112', 'coverflow', 3000);
}
