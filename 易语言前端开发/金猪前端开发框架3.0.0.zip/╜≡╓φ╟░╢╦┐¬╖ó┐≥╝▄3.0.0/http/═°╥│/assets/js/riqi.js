﻿
$('#cdd34').change(function(){
    var s;
    
    s = $('#cdd34').val();
    s = 功能_时间去T (s);
    
    组件_失去焦点 (this);
    
    layer.alert(s);
    
});
