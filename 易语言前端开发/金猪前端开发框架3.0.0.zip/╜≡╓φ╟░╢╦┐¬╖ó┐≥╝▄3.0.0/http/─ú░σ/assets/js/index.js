﻿
var hsspan = '';
index_main_stat();
function index_main_stat() {
    var bb = '';
    bb = '网页开发框架v2.3.1.e';
    hsspan = '<span style="color: rgb(20,22,24);">{1}</span>';
    layer.msg ('感谢使用' + bb);
    
    设置_轮播图 ('#gt1', 'coverflow', 3000);
}
